<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class ShiftModal extends CI_Model {
    public function AddShift(){}
    public function EditShift(){}
    public function DeleteShift(){}
    public function ShowShift(){}
}

?>