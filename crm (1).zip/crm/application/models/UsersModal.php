<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class UsersModal extends CI_Model {
    public function AddUser(){}
    public function EditUser(){}
    public function DeleteUser(){}
    public function ShowUser(){}
}

?>